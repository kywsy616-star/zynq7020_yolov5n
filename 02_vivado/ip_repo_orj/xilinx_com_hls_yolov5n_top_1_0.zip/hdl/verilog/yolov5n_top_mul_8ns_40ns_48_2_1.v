// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2020.2 (64-bit)
// Copyright 1986-2020 Xilinx, Inc. All Rights Reserved.
// ==============================================================

`timescale 1 ns / 1 ps

module yolov5n_top_mul_8ns_40ns_48_2_1_Multiplier_11(clk, ce, a, b, p);
input clk;
input ce;
input [8 - 1 : 0] a;
input [40 - 1 : 0] b;
output[48 - 1 : 0] p;
reg signed [48 - 1 : 0] p;
wire [48 - 1 : 0] tmp_product;

assign tmp_product = a * b;
always @ (posedge clk) begin
    if (ce) begin
        p <= tmp_product;
    end
end
endmodule
`timescale 1 ns / 1 ps
module yolov5n_top_mul_8ns_40ns_48_2_1(
    clk,
    reset,
    ce,
    din0,
    din1,
    dout);

parameter ID = 32'd1;
parameter NUM_STAGE = 32'd1;
parameter din0_WIDTH = 32'd1;
parameter din1_WIDTH = 32'd1;
parameter dout_WIDTH = 32'd1;
input clk;
input reset;
input ce;
input[din0_WIDTH - 1:0] din0;
input[din1_WIDTH - 1:0] din1;
output[dout_WIDTH - 1:0] dout;



yolov5n_top_mul_8ns_40ns_48_2_1_Multiplier_11 yolov5n_top_mul_8ns_40ns_48_2_1_Multiplier_11_U(
    .clk( clk ),
    .ce( ce ),
    .a( din0 ),
    .b( din1 ),
    .p( dout ));

endmodule

